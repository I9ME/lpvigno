<ul class="SocialMediaBar u-positionRelative u-displayFlex u-flexDirectionRow u-sizeFull u-flexJustifyContentCenter">
			
	<li class="SocialMediaBar-site u-displayFlex u-flexAlignItemsCenter">
		<a class="u-displayBlock LinkHover" href="http://www.barneysburger.com.br" target="_blank">
			<i class="FigureIcon FigureIcon--a FigureIcon--site is-animating"></i>
			<i class="FigureIcon FigureIcon--b FigureIcon--site--hover is-animating"></i>
		</a>
	</li>
	<li class="SocialMediaBar-facebook u-displayFlex u-flexAlignItemsCenter">
		<a class="u-displayBlock LinkHover" href="https://www.facebook.com/lovebarneys/" target="_blank">
			<i class="FigureIcon FigureIcon--a FigureIcon--facebook is-animating"></i>
			<i class="FigureIcon FigureIcon--b FigureIcon--facebook--hover is-animating"></i>
		</a>
	</li>
	<li class="SocialMediaBar-instagram u-displayFlex u-flexAlignItemsCenter">
		<a class="u-displayBlock LinkHover" href="https://www.instagram.com/barneysburger/" target="_blank">
			<i class="FigureIcon FigureIcon--a FigureIcon--instagram is-animating"></i>
			<i class="FigureIcon FigureIcon--b FigureIcon--instagram--hover is-animating"></i>
		</a>
	</li>
	<li class="SocialMediaBar-youtube u-displayFlex u-flexAlignItemsCenter">
		<a class="u-displayBlock LinkHover" href="https://www.youtube.com/channel/UC-xbLIhAvmpG1u9G-kQ0HWQ" target="_blank">
			<i class="FigureIcon FigureIcon--a FigureIcon--youtube is-animating"></i>
			<i class="FigureIcon FigureIcon--b FigureIcon--youtube--hover is-animating"></i>
		</a>
	</li>

</ul>