<ul>
	<?php wp_get_archives( array( 'type' => 'monthly', 'limit' => 12 ) ); ?>
</ul>