<div id="Lightbox--container" class="Lightbox Lightbox--inactive Lightbox--style1 u-positionFixed u-displayBlock u-sizeFull u-sizeHeight100">
	<div class="Lightbox-window is-animating u-positionAbsolute u-displayBlock u-heightAuto u-boxShadow u-absoluteCenterMiddle">
		<i class="Lightbox-closeButton LightboxClose u-displayBlock u-isActionable">
			<svg class="iconClose NavigationButton-icon u-icon is-animating is-animating--switch is-animating--switch--imgB is-animating--rotate">
				<use xlink:href="#iconClose"></use>
			</svg>
		</i>
		<div class="Lightbox-window-content u-sizeFull u-overflowYauto u-positionRelative u-displayBlock">
		</div>
	</div>
	<div class="Lightbox-mask LightboxClose is-animating u-positionAbsolute u-displayBlock u-sizeFull u-sizeHeight100 u-overflowHidden"></div>

</div>


