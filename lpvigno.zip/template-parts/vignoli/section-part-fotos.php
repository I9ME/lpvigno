
<div class="Section-items-item-content">
	<h4 class="Section-items-item-title u-marginBottom--inter">
		Conheça um pouco da essência da Vignoli...
	</h4>
	<div class="Section-items-item-gallery Gallery Gallery--fotos">
	</div>
	
</div>