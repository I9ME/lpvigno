
<div class="Section-items-item-content">
	<!-- <h4 class="Section-items-item-title u-marginBottom--inter">
		SUBTITLE
	</h4> -->
	<div class="Section-items-item-content Diferenciais">
		<ul class="Diferenciais-items u-displayFlex u-flexDirectionColumn">
			<li class="Diferenciais-items-item u-sizeFull u-marginBottom--inter u-alignCenter">
				<figure class="Diferenciais-items-item-figure FigureIcon FigureIcon--legumes u-icon"></figure>
				<h3 class="Diferenciais-items-item-title u-marginBottom--inter--half">MOLHO ARTESANAL</h3>
				<p class="Diferenciais-items-item-resume">
					Receita secreta da família, produzida, produzido em um processo artesanal lento e muito cuidadoso, a partir de tomates frescos e selecionados, mantendo as ricas propriedades do tomate.
				</p>
			</li>
			<li class="Diferenciais-items-item u-sizeFull u-marginBottom--inter u-alignCenter">
				<figure class="Diferenciais-items-item-figure FigureIcon FigureIcon--azeite u-icon"></figure>
				<h3 class="Diferenciais-items-item-title u-marginBottom--inter--half">AZEITE TEMPERADO</h3>
				<p class="Diferenciais-items-item-resume">
					De sabor único, seja com alecrim e pimenta ou de alho, realçando o sabor das nossas incríveis pizzas.
				</p>
			</li>
			<li class="Diferenciais-items-item u-sizeFull u-marginBottom--inter u-alignCenter">
				<figure class="Diferenciais-items-item-figure FigureIcon FigureIcon--queijo u-icon"></figure>
				<h3 class="Diferenciais-items-item-title u-marginBottom--inter--half">QUEIJOS</h3>
				<p class="Diferenciais-items-item-resume">
					Queijo de alto padrão de qualidade, com blend EXCLUSIVO para a Vignoli, mantendo o padrão do sabor incomparável das nossas pizzas em todas as unidades.
				</p>
			</li>
			<li class="Diferenciais-items-item u-sizeFull u-marginBottom--inter u-alignCenter">
				<figure class="Diferenciais-items-item-figure FigureIcon FigureIcon--luvinhas u-icon"></figure>
				<h3 class="Diferenciais-items-item-title u-marginBottom--inter--half">LUVINHAS</h3>
				<p class="Diferenciais-items-item-resume">
					Pizza feita a mão para comer com as mãos. Na Vignoli, comer usando as famosas luvinhas faz parte da nossa tradição e da experiência Vignoli.
				</p>
			</li>
			<li class="Diferenciais-items-item u-sizeFull u-marginBottom--inter u-alignCenter">
				<figure class="Diferenciais-items-item-figure FigureIcon FigureIcon--fatiapizza u-icon"></figure>
				<h3 class="Diferenciais-items-item-title u-marginBottom--inter--half">PIZZA FINA, CROCANTE E SAUDÁVEL</h3>
				<p class="Diferenciais-items-item-resume">
					Nossas massas são saudáveis, pois não levam gorduras hidrogenadas, leite ou ovos. Usamos água mineral filtrada, e feitas diariamente, utilizando os melhores ingredientes do mercado nacional e internacional.
				</p>
			</li>
			<li class="Diferenciais-items-item u-sizeFull u-marginBottom--inter u-alignCenter">
				<figure class="Diferenciais-items-item-figure FigureIcon FigureIcon--macarrao u-icon"></figure>
				<h3 class="Diferenciais-items-item-title u-marginBottom--inter--half">OPÇÃO DE MASSA INTEGRAL</h3>
				<p class="Diferenciais-items-item-resume">
					Massa com alto teor de fibras, que a torna mais nutritiva.
				</p>
			</li>
		</ul>
	</div>
	
</div>