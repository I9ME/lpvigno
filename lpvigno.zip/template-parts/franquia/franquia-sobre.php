<section id="afranquia" class="Section Section--style1 Section--aFranquia u-positionRelative u-paddingTop--inter--half">
	<div class="Section-mainContent u-paddingVertical u-paddingBottom">
		<div class="u-maxSize--container u-alignCenterBox u-alignCenter u-displayFlex u-flexDirectionColumn u-flexSwitchRow--reverse u-positionRelative"><!-- Max Size Container -->
			<div class="Section--texts u-displayFlex u-flexDirectionColumn u-size12of24 u-paddingTop u-marginTop--inter--half">
				<header class="Section-header u-marginBottom--inter u-size16of24 u-alignCenterBox u-paddingVertical u-displayFlex u-flexDirectionColumn u-flexAlignItemsCenter">
					<figure class="ArabescoTop--color_15 u-displayBlock"></figure>
					<h2 class="Section-header-title Section-header-title--beforeTitleLine u-alignCenter u-paddingHorizontal--inter--half u-sizeFull">A FRANQUIA <strong>VIGNOLI</strong></h2>
				</header>
				<div class="Section-content u-alignJustify">
					<h3 class="Section-content-subtitle">
						Eleita 8 vezes como a melhor pizza de Fortaleza pela Veja Comer e Beber  e 2 vezes consecutivas a melhor pizza de Salvador.
					</h3>
					<p class="Section-content-text u-marginTop--inter--half">
						O ambiente aconchegante ao ar livre, com peças decorativas originais e muitas antiguidades, é ideal para quem procura conforto e um clima intimista na hora do jantar. No cardápio, são oferecidas pizzas, saladas e massas para todos os gostos, além de uma variada carta de vinhos.
					</p>
				</div>
			</div>
			<div class="Section-imageMain Section-gridElastic u-size11of24 u-marginTop--inter u-positionRelative">
					<figure class="Section-gridElastic-item Image_1 u-positionAbsolute u-absoluteCenterMiddle u-zIndex4 u-lineHeight0">
						<img class="Section-gridElastic-item-src u-boxShadow" src="<?php echo get_template_directory_uri(); ?>/assets/images/img-1.png" alt="Pizza Vignoli" />
					</figure>
					<figure class="Section-gridElastic-item Image_2 u-lineHeight0 u-zIndex3 u-paddingRight--inter--half u-paddingBottom--inter--half" data-paroller-factor="-0.05" data-paroller-type="foreground" data-paroller-direction="horizontal">
						<img class="Section-gridElastic-item-src u-boxShadow" src="<?php echo get_template_directory_uri(); ?>/assets/images/img-2.png" alt="Pizza Vignoli" />
					</figure>
					<figure class="Section-gridElastic-item Image_3 u-lineHeight0 u-zIndex3 u-paddingLeft--inter--half u-paddingBottom--inter--half" data-paroller-factor="0.05" data-paroller-type="foreground" data-paroller-direction="horizontal">
						<img class="Section-gridElastic-item-src u-boxShadow" src="<?php echo get_template_directory_uri(); ?>/assets/images/img-3.png" alt="Pizza Vignoli" />
					</figure>
					<figure class="Section-gridElastic-item Image_4 u-lineHeight0 u-zIndex3 u-paddingRight--inter--half u-paddingTop--inter--half" data-paroller-factor="-0.05" data-paroller-type="foreground" data-paroller-direction="horizontal">
						<img class="Section-gridElastic-item-src u-boxShadow" src="<?php echo get_template_directory_uri(); ?>/assets/images/img-4.png" alt="Pizza Vignoli" />
					</figure>
					<figure class="Section-gridElastic-item Image_5 u-lineHeight0 u-zIndex3 u-paddingLeft--inter--half u-paddingTop--inter--half" data-paroller-factor="0.05" data-paroller-type="foreground" data-paroller-direction="horizontal">
						<img class="Section-gridElastic-item-src u-boxShadow" src="<?php echo get_template_directory_uri(); ?>/assets/images/img-5.png" alt="Pizza Vignoli" />
					</figure>
			</div>
		</div>
	</div>
	<?php get_template_part('template-parts/franquia/franquia','subsection'); ?>

</section>